/* Do not modify */
void removeOddsValue(int *&arrayPtr, int &size);